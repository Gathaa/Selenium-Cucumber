package StepDefinitions;

import org.openqa.selenium.By;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Addtocart {
	public Web connection = new Web();
    @Given("the user is logged into their account for adding to cart")
    public void the_user_is_logged_into_their_account_for_adding_to_cart() {
        System.out.println("User is logged into their account");
        connection.invokeBrowser();
        connection.login("Aimenguedhami6@gmail.com","Aymen123");
    }
    @When("the user selects an item")
    public void the_user_selects_an_item_from_the_search_results() {
        connection.driver.findElement(By.xpath("//*[@id=\"link-custom-page-homme-1\"]")).click();
    }

    @When("the user presses {string} for the selected item")
    public void the_user_presses_add_to_cart_for_the_selected_item(String action) {
    	connection.driver.findElement(By.xpath("//*[@id=\"js-product-list\"]/div/div[8]/article/div[2]/div[2]/ul/li[1]/div/a/button/span")).click();
    }

    @Then("the selected item is added to the user's cart")
    public void the_selected_item_is_added_to_the_user_s_cart() {
        System.out.println("Produit ajouté au panier avec succès");
        
    }
}