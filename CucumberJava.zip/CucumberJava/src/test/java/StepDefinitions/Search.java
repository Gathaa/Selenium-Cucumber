package StepDefinitions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;
public class Search {
    Web connection = new Web();

    @Given("the user is on the homepage")
    public void the_user_is_on_the_homepage() {
        connection.invokeBrowser();
    }

    @When("the user searches with an empty input")
    public void the_user_searches_with_an_empty_input() {
        connection.driver.findElement(By.id("pos_query_top")).click();
        connection.driver.findElement(By.id("pos_query_top")).sendKeys("");
        connection.driver.findElement(By.xpath("//*[@id=\"searchbox\"]/button")).submit();
    }

    @Then("an error message {string} should be displayed")
    public void an_error_message_should_be_displayed(String expectedErrorMessage) {
        String actualErrorMessage = connection.driver.findElement(By.xpath("//*[@id=\"content\"]/h4")).getText();
        assertEquals(expectedErrorMessage, actualErrorMessage);
    }

    @When("the user searches with {string}")
    public void the_user_searches_with(String query) {
        connection.driver.findElement(By.id("pos_query_top")).click();
        connection.driver.findElement(By.id("pos_query_top")).sendKeys(query);
        connection.driver.findElement(By.xpath("//*[@id=\"searchbox\"]/button")).submit();
    }

    @Then("{string} should be displayed on the products page")
    public void should_be_displayed_on_the_products_page(String expectedText) {
        String actualText = connection.driver.findElement(By.xpath("//*[@id=\"pos_query_top\"]")).getText();
        assertEquals(expectedText, actualText);
    }


}
