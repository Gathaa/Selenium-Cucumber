package StepDefinitions;

import static org.junit.Assert.assertEquals;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {
    Web connection = new Web();

    @Given("the user starts the browser and navigates to the homepage")
    public void the_user_starts_the_browser_and_navigates_to_the_homepage() {
        connection.invokeBrowser();
    }

    @When("the user logs in with valid credentials")
    public void the_user_logs_in_with_valid_credentials() {
        connection.login("standard_user", "secret_sauce");
    }

    @Then("the user is redirected to the account page titled {string}")
    public void the_user_is_redirected_to_the_account_page_titled(String title) {
        assertEquals(title, connection.getTitle());
    }

    @When("the user attempts to login with {string} and {string}")
    public void the_user_attempts_to_login_with_and(String username, String password) {
        connection.login(username, password);
    }

    @Then("the title of the page should be {string}")
    public void the_title_of_the_page_should_be(String title) {
        assertEquals(title, connection.getTitle());
    }
}