package StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public class Editaccount {
    Web connection = new Web();
    @Given("the user is logged into their account")
    public void the_user_is_logged_into_their_account() {
    	connection.invokeBrowser();
        connection.login("Aimenguedhami6@gmail.com", "Aymen123");
    }

    @When("the user modifies their profile")
    public void the_user_modifies_their_profile_with_firstname_lastname_and_password() {
        connection.modify("Aimen","Gdhami","Aymen123");
    }
   
    @Then("the profile is updated")
    public void the_profile_is_updated() {
      System.out.println("Account Updated Successfully! ");
    }
}
