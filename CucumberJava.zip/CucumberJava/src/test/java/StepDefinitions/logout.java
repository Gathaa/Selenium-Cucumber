package StepDefinitions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import static org.junit.Assert.assertEquals;
public class logout {
	Web connection = new Web();

    @Given("the user is logged in with valid credentials")
    public void the_user_is_logged_in_with_valid_credentials() {
        connection.invokeBrowser();
        connection.login("Aimenguedhami6@gmail.com", "Aymen123");
    }
    @When("the user initiates a logout")
    public void the_user_initiates_a_logout() {
        connection.logout();
    }

    @Then("the user should be redirected to {string}")
    public void the_user_should_be_redirected_to_the_homepage(String identifiant) {
        assertEquals(identifiant, connection.getTitle());
    }
}
