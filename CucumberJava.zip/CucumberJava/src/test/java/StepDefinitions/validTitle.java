package StepDefinitions;

import static org.junit.Assert.assertEquals;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
public class validTitle {
	  public Web connection= new Web();
	    String actualTitle ;
		@Given("User is on the home page")
		public void user_is_on_the_login_page() {
			System.out.println("User is on the home page");
	        connection.invokeBrowser();
		}
		@When("User checks the website title")
		public void user_enters_valid_credentials() {
			System.out.println("User checks the website title");
			actualTitle = connection.getTitle();
		}
		@Then("User reads the correct title")
		public void user_is_redirected_to_the_homepage() {
			System.out.println("User reads the correct title");

	    	assertEquals("Boutique de chaussures et d'articles de sport en Tunisie", actualTitle);

		}
}
